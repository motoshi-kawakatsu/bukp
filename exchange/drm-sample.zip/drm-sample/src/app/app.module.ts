import 'hammerjs';

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialModule } from '@angular/material';
import { DRMRoutesModule } from './app.routes';

import { AppComponent } from './app.component';
import { CustomerListComponent } from './master/customer/customer-list/customer-list.component';
import { CustomerNewComponent } from './master/customer/customer-new/customer-new.component';
import { CustomerDetailComponent } from './master/customer/customer-detail/customer-detail.component';
import { PaginationComponent } from './controls/pagination/pagination.component';
@NgModule({
  declarations: [
    AppComponent,
    CustomerListComponent,
    CustomerNewComponent,
    CustomerDetailComponent,
    PaginationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    FlexLayoutModule,
    MaterialModule,
    DRMRoutesModule
  ],
  providers: [],

  bootstrap: [AppComponent]
})
export class AppModule { }
