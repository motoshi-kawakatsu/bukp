import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HashLocationStrategy, PathLocationStrategy, LocationStrategy } from "@angular/common";

import { CustomerListComponent } from './master/customer/customer-list/customer-list.component';
import { CustomerNewComponent } from './master/customer/customer-new/customer-new.component';
import { CustomerDetailComponent } from './master/customer/customer-detail/customer-detail.component';

const AppRoutes: Routes = [
  {path: '', redirectTo: 'customers', pathMatch: 'full'},
  {path: 'customers', component: CustomerListComponent},
  {path: 'customer', component: CustomerNewComponent},
  {path: 'customers/:id', component: CustomerDetailComponent},
];

@NgModule({
  exports: [RouterModule],
  imports: [
    RouterModule.forRoot(AppRoutes)
  ],
  providers: [
    { provide: LocationStrategy, useClass: PathLocationStrategy }
  ]
})
export class DRMRoutesModule { }