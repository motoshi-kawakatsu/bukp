/**
* メッセージ一覧
*/
export class Message {


  readonly C_NM_0001: string = "削除してよろしいですか？";
  readonly C_NM_0002: string = "更新してよろしいですか？";

  readonly E_IC_0001= "1%は必須です。";
  readonly E_IC_0002= "正しい1%を入力してください。";
  readonly E_IC_0003= "この電話番号は既に登録されました。";

  readonly I_DB_0001= "対象のデータがありません。";

}
