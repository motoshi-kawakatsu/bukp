import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.styl']
})

export class PaginationComponent implements OnInit {
  @Input('pageParams') pageParams:any;
  @Output() changeCurPage:EventEmitter<Number> = new EventEmitter;

  /**
  * コンストラクタ
  */
  constructor() {
  }

  /**
  * 初期化処理
  */
  ngOnInit() {
  }

  /**
  * ページ選択
  */
  changePage(pageNo:any) {
    this.pageParams.curPage = pageNo;
    this.changeCurPage.emit(this.pageParams.curPage);
  }
}
