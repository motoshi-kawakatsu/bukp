import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

import { PageService } from "../../../service/page.service";
import { Customer } from "../../../models/customer";
import { CustomerService } from "../../../service/master/customer.service";
import { CustomerTypeService } from "../../../service/master/customer-type.service";
import { Message } from "../../../common/message/messages";

@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.styl'],
  providers: [PageService, CustomerService, CustomerTypeService, Message]
})

/**
 * カスタマーの詳細と編集画面クラス
 */
export class CustomerDetailComponent implements OnInit {
  /**献金者管理情報*/
  customer: Customer;
  /**初期献金者管理情報*/
  originalCustomer: Customer;
  /**詳細モードフラグ*/
  isDetailMode: boolean;
  /**編集ボタン文字*/
  editText: string;
  /**名簿種別*/
  catogorys = [];

  /**
   * コンストラクタ
   */
  constructor(private _pageService: PageService, private _customerService: CustomerService, private route: ActivatedRoute, private _customerTypeService: CustomerTypeService, private _message: Message) {

  }

  /**
   * 画面初期表示
   */
  ngOnInit() {
    let id = undefined;
    this.route.params.subscribe(
      params => {
        id = +params['id'];
      });
    this.customer = new Customer();
    this._customerService.getCustomerById(id).subscribe(v => {
      this.customer = v;
      this.customer.mailAddress = this.customer.mailAddress.trim();
      this.originalCustomer = this.cloneCustomer(this.customer);
    });
    this.isDetailMode = true;
    this.editText = "編集";
    this._customerTypeService.getAll().subscribe(res => this.catogorys = res,
      error => {
        this._pageService.openSnackBar(error, "");
      });
  }

  /**
   * 戻るボタンをタップ
   */
  goBack() {
    this._pageService.goBack();
  }

  /**
   * 編集ボタンをタップ
   */
  changeMode() {
    if (!this.isDetailMode) {
      let _this = this;
      this._customerService.isCustomerExist(this.customer.phoneNumber, this.customer.id).subscribe(
        res => {
          if (res) {
            _this._pageService.openSnackBar(_this._message.E_IC_0003, "");
          } else {
            _this.updateCustomer();
          }
        },
        err => {
          _this._pageService.openSnackBar(err, "");
        }
      );
    } else {
      this.isDetailMode = false;
      this.editText = "変更";
    }
  }

  /**
   * リセットボタンをタップ
   */
  onReset() {
    this.customer = this.cloneCustomer(this.originalCustomer);
  }

  /**
   * 入力有無チェックメッセージを取得
   */
  getRequireMessage(param: string): string {
    return this._message.E_IC_0001.replace("1%", param);
  }

  /**
   * バリデーションチェックメッセージを取得
   */
  getInputErrorMessage(replace: string, param: string): string {
    return this._message.E_IC_0002.replace("1%", replace).concat(param == undefined ? "" : param);
  }

  /**
   * 献金者管理情報の更新
   */
  private updateCustomer() {
    this.customer.mailAddress = this.customer.mailAddress == undefined ? "" : this.customer.mailAddress.trim();
    this._customerService.updateCustomerById(this.customer).subscribe(
      res => {
        let snackBarRef = this._pageService.openSnackBar("変更成功しました。","",2000);
        snackBarRef.afterDismissed().subscribe(() => {
          this._pageService.goto("/customers");
        });
      },
      error => {
        this._pageService.openSnackBar(error, "");
      }
    );
  }

  /**
   * 献金者管理情報のクローン
   */
  private cloneCustomer(customer: Customer): Customer {
    let cloneCustomer = new Customer();
    cloneCustomer.mailAddress = customer.mailAddress;
    cloneCustomer.address = customer.address;
    cloneCustomer.fullName = customer.fullName;
    cloneCustomer.id = customer.id;
    cloneCustomer.phoneNumber = customer.phoneNumber;
    cloneCustomer.postalCode = customer.postalCode;
    cloneCustomer.typeId = customer.typeId;
    return cloneCustomer;
  }
}
