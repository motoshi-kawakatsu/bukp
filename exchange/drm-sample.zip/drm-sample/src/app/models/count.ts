export class Count {
  count: number
}
