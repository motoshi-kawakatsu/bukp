export class CustomerType {
  id: string;
  name: string;
}
