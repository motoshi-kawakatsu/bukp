export class Customer {
  id: number;
  fullName: string;
  mailAddress: string;
  phoneNumber: string;
  postalCode: string;
  address: string;
  typeId: number;
}
