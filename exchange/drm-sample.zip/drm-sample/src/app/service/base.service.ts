
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';

export class BaseService {

  // サービスのルートパース
  readonly rootPath:string;

  /**
  * コンストラクタ
  */
  constructor() {
    this.rootPath = "http://localhost:3000/api";
  }

  /**
  * エラー処理
  */
  public handleError(error: any) {
    console.error('An error occurred', error);
    return Observable.throw(error.json().error || 'サーバーに接続できませんでした。');
  }

}
