import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { BaseService } from '../base.service';
import { CustomerType } from '../../models/customer-type';

/**
* カスタマータイプサービスクラス
*/
@Injectable()
export class CustomerTypeService extends BaseService {

  private _http: Http;

  /**
  * コンストラクタ
  */
  constructor(http: Http) {
    super();
    this._http = http;
  }

  /**
  * カスタマータイプを全件取得
  */
  getAll():Observable<CustomerType[]> {
    return this._http.get(this.rootPath + '/customerTypes')
    .map(res=> res.json())
    .catch(this.handleError);
  }
}
