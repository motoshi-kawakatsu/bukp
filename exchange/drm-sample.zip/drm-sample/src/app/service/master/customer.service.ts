import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { BaseService } from '../base.service';
import { Customer } from '../../models/customer';
import { Count } from '../../models/count';

/**
 * カスタマーサービスクラス
 */
@Injectable()
export class CustomerService extends BaseService {

  private _http: Http;

  /**
  * コンストラクタ
  */
  constructor(http: Http) {
    super();
    this._http = http;
  }

  /**
  * カスタマー１件追加
  */
  addCustomer(customer: Customer): Observable<Customer> {
    if (customer == undefined) {
      console.log("customer Empty");
    }
    return this._http.put(this.rootPath + '/customers', customer)
      .map(res => res.json)
      .catch(this.handleError);
  }

  /**
  * カスタマー１件更新
  */
  updateCustomerById(customer: Customer): Observable<Customer> {
    return this._http.put(this.rootPath + '/customers/' + new String(customer.id), customer)
      .map(res => res.json)
      .catch(this.handleError);
  }

  /**
  * カスタマーの検索処理
  */
  getCustomers(customer: Customer, pageNo: number, orderCol: string, types: string): Observable<Customer[]> {
    let searchPath = this.buildSearchPath(this.rootPath + "/customers/?", customer, types, "filter");
    searchPath += '&filter[skip]=' + (pageNo - 1) * 20 + '&filter[limit]=20' + '&filter[order]=' + orderCol;
    return this._http.get(searchPath)
      .map(res => res.json())
      .catch(this.handleError);
  }

  /**
  * カスタマー件数の取得
  */
  getCusCount(customer: Customer, types: string): Observable<Count> {
    let searchPath = this.buildSearchPath(this.rootPath + "/customers/count?", customer, types);
    return this._http.get(searchPath).map(res => res.json()).catch(this.handleError);
  }

  /**
  * カスタマー存在するかどうかの判断
  *　true:存在　false:存在しない
  */
  isCustomerExist(phoneNumber: string, id?: number): Observable<boolean> {
    let searchPath = this.rootPath + "/customers/?" + '&filter[where][phoneNumber]=' + phoneNumber;
    return this._http.get(searchPath).map((res) => {
      let _res = res.json();

      if (_res.length == 0) {
        return false;
      }

      if (id && _res.length != 0) {
        for (let i = 0; i < _res.length; i++) {

          if (_res[i].id != id) {
            return true;
          }
        }
        return false;
      }
      return true;
    }).catch(this.handleError);

  }

  /**
   * カスタマーをキーで１件取得
   */
  getCustomerById(id: string): Observable<Customer> {
    return this._http.get(this.rootPath + '/customers/' + id)
      .map(res => res.json())
      .catch(this.handleError);;
  }

  /**
  * 検索条件の作成
  */
  private buildSearchPath(path: string, customer: Customer, types: string, filter?: string) {
    filter = filter || '';

    if (customer.fullName) {
      path += '&' + filter + '[where][fullName][like]=' + customer.fullName;
    }
    if (customer.address) {
      path += '&' + filter + '[where][address][like]=' + customer.address;
    }
    if (customer.postalCode) {
      path += '&' + filter + '[where][postalCode]=' + customer.postalCode;
    }
    if (customer.phoneNumber) {
      path += '&' + filter + '[where][phoneNumber]=' + customer.phoneNumber;
    }
    if (customer.mailAddress) {
      path += '&' + filter + '[where][mailAddress][like]=' + customer.mailAddress;
    }
    if (types) {
      let typeIds = types.split(':');
      let inq = typeIds.length > 1 ? '[inq]' : "";
      for (let i = 0; i < typeIds.length; i++) {
        path += '&' + filter + '[where][typeId]' + inq + '=' + typeIds[i];
      }
    }

    return path;
  }
}
