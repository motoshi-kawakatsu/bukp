import { MdSnackBar, MdSnackBarConfig } from '@angular/material';
import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router'

/**
 * 画面のベースクラス
 */
@Injectable()
export class PageService {
  private _snackBar: MdSnackBar;
  private _location: Location;
  private _router: Router;

  /**
  * コンストラクタ
  */
  constructor(snackBar: MdSnackBar, location: Location, router: Router) {
    this._snackBar = snackBar;
    this._location = location;
    this._router = router;
  }

  /**
   * メッセージの表示処理
   */
  openSnackBar(error: any, action?: string, duration?: number) {
    let _msg;
    if (typeof error=='string'&&error.constructor==String) {
      _msg = error;
    } else {
      _msg = "status:" + error.statusCode + " message:" + error.message;
    }
    if (duration == undefined) {
      duration = 3000;
    }
    return this._snackBar.open(_msg, action, { duration: duration });
  }
  /**
   * 先 のページへ進む
   */
  forward() {
    this._location.forward();
  }

  /**
   * 前のページへ戻る
   */
  goBack() {
    this._location.back();
  }

  // 指定パースへ遷移
  goto(commands: any[] | string) {
    let routerLink = Array.isArray(commands) ? commands : [commands];
    this._router.navigate(routerLink);
  }

}
