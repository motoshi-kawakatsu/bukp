'use strict';

module.exports = function(Customertype) {

};
