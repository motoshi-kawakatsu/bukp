'use strict';

module.exports = function(Customer) {

};
