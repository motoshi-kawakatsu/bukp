import { Component,OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { FormControl } from '@angular/forms';

import { CustomerService } from '../../../service/master/customer.service';
import { CustomerTypeService } from '../../../service/master/customer-type.service';
import { PageService } from '../../../service/page.service';
import { Customer } from '../../../models/customer';
import { CustomerType } from '../../../models/customer-type';
import { Count } from '../../../models/count';
import { Message } from '../../../common/message/messages';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.styl'],
  providers: [CustomerService, CustomerTypeService, PageService, Message]
})

/**
* カスタマーの検索画面クラス
*/
export class CustomerListComponent implements OnInit{
  selected :boolean[];
  orderCol = 'fullName';
  order = 'ASC';
  pageParam = {
    pageSize: 20,
    totalNum: 0,
    curPage: 1,
    totalPage: 0,
    pages: []
  };
  typeIds:CustomerType[];
  customer = new Customer();
  customers: Customer[];
  count: Count;

  /**
  * コンストラクタ
  */
  constructor(private _pageService: PageService, private _customerService: CustomerService,
   private _customerTypeService: CustomerTypeService, private _message: Message) {
  }

  /**
  * 画面の初期化
  */
  ngOnInit() {
    if (sessionStorage.getItem('order')) {
      this.order = JSON.parse(sessionStorage.getItem('order'));
      this.orderCol = JSON.parse(sessionStorage.getItem('orderCol'));
    }
    if (sessionStorage.getItem('pageParam')) {
      this.pageParam = JSON.parse(sessionStorage.getItem('pageParam'));
    }
     this.getTypeIds();
  }

  /**
  * 検索ボタンのクリック
  */
  selectCustomer(){
    this.pageParam.curPage = 1;
    this.orderCol = 'fullName';
    this.order = 'ASC';
    this.onSubmit();
  }

  /**
  * 名簿種別を取得
  */
  getTypeIds(){
    let _this =this;
    this._customerTypeService.getAll()
      .subscribe(
        types => _this.editTypes(types),
        error =>_this._pageService.openSnackBar(error, "")
      );
  }

  /**
  *  カスタマーを取得
  */
  onSubmit() {
    let _this =this;
    let types = '';
    for (let i in this.selected) {
      if (this.selected[i]) {
         types = types + (parseInt(i)+1)+':';
      }
    }
    sessionStorage.setItem("customer",JSON.stringify(this.customer));
    sessionStorage.setItem("typeIds" ,JSON.stringify(this.selected));
    sessionStorage.setItem("pageParam" ,JSON.stringify(this.pageParam));

    types = types.substr(0, types.length - 1);
    let orderby = _this.orderCol + ' ' + _this.order;

    this._customerService.getCustomers(_this.customer, _this.pageParam.curPage, orderby, types)
      .subscribe(
        customers => {_this.customers = customers},
        error => _this._pageService.openSnackBar(error, "")
      );

    this._customerService.getCusCount(_this.customer,types)
      .subscribe(
        counts => _this.setPageData(counts),
        error => _this._pageService.openSnackBar(error, "")
      );
  }

  /**
  *  名簿種別データを編集
  */
  editTypes(types:CustomerType[]){
    this.selected = new Array<boolean>(types.length);
    if (sessionStorage .getItem('typeIds')){
      let temp  = JSON.parse(sessionStorage .getItem('typeIds'));
      if (temp.length==types.length) {
        this.selected = temp;
      }
    }
    this.typeIds = types;
    if (sessionStorage.getItem('customer')) {
      this.customer = JSON.parse(sessionStorage .getItem('customer'));
      this.onSubmit();
    }
  }

  /**
  *  カスタマーデータのソート
  */
  orderData(columnName:string){
    // ソート列設定
    if (this.orderCol == columnName) {
      if (this.order == 'ASC') {
        this.order = 'DESC';
      }
      else {
        this.order = 'ASC';
      }
    }
    else {
      this.order = 'ASC';
      this.orderCol = columnName;
    }
    if (sessionStorage .getItem('typeIds')){
        let temp  = JSON.parse(sessionStorage .getItem('typeIds'));
        this.selected = temp;
    }
    if (sessionStorage .getItem('customer')) {
       this.customer=JSON.parse(sessionStorage .getItem('customer'));
    }
    // ソート条件を一時保持
    sessionStorage.setItem("order" ,JSON.stringify(this.order));
    sessionStorage.setItem("orderCol" ,JSON.stringify(this.orderCol));

    this.pageParam.curPage = 1;
    this.onSubmit();
   }

  /**
  *  ページデータを設定
  */
  setPageData(counts: Count) {

    this.count = counts;
    this.pageParam.totalNum = this.count.count;
    this.pageParam.totalPage = Math.ceil(this.count.count / 20);
    if (this.count.count == 0) {
      this._pageService.openSnackBar(this._message.I_DB_0001, "")
    }
    this.pageParam.pages=this.getPageList(this.pageParam);

  }

  /**
  *  ページデータを取得
  */
  getPageData(pageNo: any) {
    let _this = this;
    this.pageParam.curPage = pageNo;
    if (sessionStorage.getItem('order')) {
      this.order = JSON.parse(sessionStorage.getItem('order'));
      this.orderCol = JSON.parse(sessionStorage.getItem('orderCol'));
    }
    if (sessionStorage .getItem('typeIds')){
        let temp  = JSON.parse(sessionStorage .getItem('typeIds'));
        this.selected = temp;
    }
    if (sessionStorage .getItem('customer')) {
       this.customer=JSON.parse(sessionStorage .getItem('customer'));
    }
    this.onSubmit();
   }

 /**
  * ページリスト作成
  */
  getPageList(pageParams:any) {
    // ページ設定
    let pageList=[];
    if (pageParams.totalPage <= 5) {
      for (let i = 0; i < pageParams.totalPage; i++) {
        pageList.push(
         {pageNo:i + 1}
        );
      }
    } else if (pageParams.totalPage - pageParams.curPage < 5 && pageParams.curPage > 4) {
      pageList = [
        {
          pageNo: pageParams.curPage - 4
        }, {
          pageNo: pageParams.curPage - 3
        }, {
          pageNo: pageParams.curPage - 2
        }, {
          pageNo: pageParams.curPage - 1
        }, {
          pageNo: pageParams.curPage
        }
      ];
    } else {
      let cur = Math.floor((pageParams.curPage - 1) / 5) * 5 + 1;
      pageList = [
        {
          pageNo: cur
        }, {
          pageNo: cur + 1
        }, {
          pageNo: cur + 2
        }, {
          pageNo: cur + 3
        }, {
          pageNo: cur + 4
        },
      ];
    }
    return pageList;
  }

  /**
  *  名簿種別選択設定
  */
  setSelectedType(id: number) {
    this.selected[id-1] = !this.selected[id-1];
  }

  /**
  *  テーブル行のダブルクリック
  */
  onRowDoubleClick(id: number){
    this._pageService.goto("/customers/"+id);
  }

}
