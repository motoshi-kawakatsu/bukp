import { Component, OnInit } from '@angular/core';

import { PageService } from '../../../service/page.service';
import { Customer } from '../../../models/customer';
import { CustomerService } from '../../../service/master/customer.service';
import { CustomerTypeService } from '../../../service/master/customer-type.service';
import { Message } from '../../../common/message/messages';

@Component({
  selector: 'app-customer-new',
  templateUrl: './customer-new.component.html',
  styleUrls: ['./customer-new.component.styl'],
  providers: [PageService, CustomerService, CustomerTypeService, Message]
})
/**
* カスタマーの登録画面クラス
*/
export class CustomerNewComponent implements OnInit {
  customer = new Customer();
  catogorys = [];

  /**
  * コンストラクタ
  */
  constructor(private _pageService: PageService, private _customerService: CustomerService, private _customerTypeService: CustomerTypeService, private _message: Message) {

  }

  /**
  * 画面の初期化
  */
  ngOnInit() {
    this._customerTypeService.getAll().subscribe(
      res => this.catogorys = res
    );
  }

  /**
  *　入力有無チェックメッセージを取得
  */
  getRequireMessage(param: string): string {
    return this._message.E_IC_0001.replace("1%", param);
  }

  /**
  *　バリデーションチェックメッセージを取得
  */
  getInputErrorMessage(replace: string, param?: string): string {
    return this._message.E_IC_0002.replace("1%", replace).concat(param == undefined ? "" : param);
  }

  /**
  * 戻るボタンのクリックイベント
  */
  goBack() {
    this._pageService.goto("/customers");
  }

  /**
  * 登録ボタンのクリックイベント
  */
  submit() {
    let _this = this;

    this._customerService.isCustomerExist(this.customer.phoneNumber).subscribe(
      res => {
        if (res) {
          _this._pageService.openSnackBar(_this._message.E_IC_0003, "");
        } else {
          _this.addCustomer();
        }
      },
      err => {
        _this._pageService.openSnackBar(err, "");
      }
    );
  }

  /**
  * カスタマー１件追加
  */
  private addCustomer() {
    this.customer.mailAddress = this.customer.mailAddress == undefined ? "" : this.customer.mailAddress.trim();
    this._customerService.addCustomer(this.customer).subscribe(
      res => {
        this._pageService.goto("/customers");
      },
      err => {
        this._pageService.openSnackBar(err, "");
      }
    );
  }
}
